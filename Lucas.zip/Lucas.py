import os, pyttsx3, sys,speech_recognition as sr, random,wikipedia,time,platform,webbrowser,datetime, shutil, json
import psutil
import requests
from pyautogui import rightClick
from keyboard import press_and_release, write


try:
    REFER = [i for i in open(f"Custom_Set\\User\\person.lucas" , "r")]
    # USER REFER = [ REFERANCE, NAME, DOB]
    USER_REFER = []
    for items in REFER:
        REF, NAME, DOB = items.split(" ; ")

    USER_REFER.append(REF)
    USER_REFER.append(NAME)
    USER_REFER.append(DOB)

except:
    print("AS User info folder is not setupped; Using User refer as Sir")
    USER_REFER = ["Sir" , "Harshit", "01-04-2008"]


REFER_USER = str(USER_REFER[0])
try: import pywhatkit
except: print(f"Please start it with Internet, {USER_REFER[0]}"); sys.exit()

path = os.getcwd()

with open(f"C:\\Users\\VIBHA\\Desktop\\thing\\Noname\\Custom_Set\\Chat.json", "r") as jsfile:
    JSFILE = json.load(jsfile)



Alternate_query = False
Attrib=[ 1 , 195 , 3 , 'Male' ]
Said_Battery_Warning = False
WARNED = False
History = []

def ChangeTEXTOnGUI(text=None):
    if text!=None:
        with open(f"System_Files\\File.txt" , "w") as FileUpdate:
            FileUpdate.write(text)
            FileUpdate.close()
        
def speak(audio, voice=None): 
    if voice != None:
        voice = int(voice)
    else:
        voice = Attrib[2]
    
    if audio!=None:
        engine = pyttsx3.init('sapi5')
        voices = engine.getProperty('voices')
        engine.setProperty('voice', voices[int(voice)].id)
        engine.setProperty('rate' , int(Attrib[1]))
        engine.setProperty("volume" , int(Attrib[0]))
        ChangeTEXTOnGUI(audio if audio!=" " else audio)
        engine.say(audio)
        engine.runAndWait()

def takecommand():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        ChangeTEXTOnGUI("Listening...")
        audio = r.listen(source)
    
    try:
        ChangeTEXTOnGUI("Recognizing...")
        query = r.recognize_google(audio, language="en-US")
        ChangeTEXTOnGUI(f"User said : {query}")
    except Exception as error:
        query = None 

    return str(query).lower()

def listtohistory(task=None):
    global History

    History.append(task)
    

def LastTask():
    global History
    try:
        length_of_history = len(History)
        task = str( History[ int( length_of_history ) ] )

    except Exception as error:
        print(error)
        task = "none"

    return task
    
class Main:
    "The Home for all Classes containing all functioning of Lucas"
    class STATE:
        def data_state():
            try:
                data = requests.get("https://www.google.com/")
                Connected = True

            except:
                Connected = False

            return Connected

    class Chatbot:
        Files_in_Custom_set = 0
        for x in os.listdir(f"{os.getcwd()}\\Custom_Set"):
            if x == "speak_attrib.value":pass
            else:Files_in_Custom_set+=1

        def Chat(text):
            global JSFILE
            words = [word for word in text.split(" ")]

            for funcs in JSFILE:
            
                if funcs == words[0]:
                    has_replied = False
                    for in_funcs in JSFILE[funcs]:
                        
                        for lines in in_funcs [ "if" ]:
                            if lines in text:
                                REPLIED_DONE = False
                                reply =  str(random.choice(in_funcs["reply"]))
                                try:
                                    extra = str(random.choice(in_funcs["extra"]))
                                except:
                                    extra=""
                                
                                reply += "\n" + extra
            
                                if "{%d_battery}" in reply:
                                    battery_percent = Main.System_Info.Battery("%")
                                    reply = reply.replace("{%d_battery}" , f"{battery_percent}")
                                
                                if "{REFER_USER}" in reply:
                                    reply = reply.replace("{REFER_USER}", REFER_USER)

                                if "{%s_STATE}" in reply:
                                    State = Main.STATE.data_state()
                                    if State:
                                        state_connected = "online"
                                    else:
                                        state_connected = "offline"
                                    reply = reply.replace("{%s_STATE}" , state_connected)

                                if "{%d_time}" in reply:
                                    Time_setted = Main.GetTime.GiveTime("time")
                                    reply = reply.replace("{%d_time}" , f"{Time_setted}")

                                if "{%s_Name}" in reply:
                                    Name = text.replace(lines+" ", ""); Name = Name.replace("say hello to " , ""); Name = Name.replace(" say hello " , "")
                                    reply = reply.replace("{%s_Name}", Name)

                                if "{%s_Appname}" in reply:
                                    AppName = text.replace(lines+" " , "")
                                    AppName = AppName.replace("open ", "")
                                    AppName = AppName.replace("start " , "")
                                    AppName = AppName.replace("start file " , "")
                                    AppName = AppName.replace("start file named " , "")

                                    reply = reply.replace("{%s_Appname}" , AppName)

                                if "{%s_Google}" in reply:
                                    Search = text.replace(lines , "")
                                    Search = Search.replace("search on google ", "")
                                    Search = Search.replace("search on google for ", "")
                                    Search = Search.replace("google search " , "")
                                    reply = reply.replace("{%s_Google}" , Search)
            
                                if "{%s_Wikipedia}" in reply:
                                    Search = text.replace(lines+" " , "")
                                    Search = Search.replace("search on wikipedia ", "")
                                    Search = Search.replace("search on wikipedia for ", "")
                                    Search = Search.replace("wikipedia search " , "")
                                    reply = reply.replace("{%s_Wikipedia}" , Search)
                                
                                if "{%s_L_task}" in reply:
                                    reply = reply.replace("{%s_L_task}" , LastTask())
                                
                                if "{%s_Day}" in reply:
                                    REPLIED_DONE = True
                                    Day = datetime.datetime.now().day
                                    reply = reply.replace("{%s_Day}", f"{Day}")


                                if "{%s_TimeOfDay}" in reply:
                                    hour = datetime.datetime.now().hour

                                    if hour > 0 and hour <= 12: DayTime = "Morning"
                                    elif hour > 12 and hour <= 15: DayTime = "Afternoon"
                                    else:
                                        DayTime = "Night"
                                    reply = reply.replace("{%s_TimeOfDay}" , DayTime)
                                
                                has_replied = True
                                speak(reply)
                                if REPLIED_DONE:pass
                                else:
                                    Main.Responder.Execute_query(text)

                    if has_replied != True:
                        Main.Responder.res(text, "Replied")

    class Wiki:
        "Searches query on Wikipedia"
        def Search(query=None, condition=None):
            query = str(query)
            query = query.replace("search " , "")
            query = query.replace("wikipedia " , "")
            query = query.replace("define " , "")
            query = query.replace("who is " , "")

            if "in expandation" in query or "in explanation" in query:
                query = query.replace("in explanation" , "")
                query = query.replace("in expandation" , "")
                expanded = 6
            else:
                expanded = False

            expanded = int(expanded) if expanded != False else 2
            condition = str(condition) if condition != None else "According to Wikipedia"
            
            if query != None:
                query = str(query)
                try: 
                    results = wikipedia.summary(query, sentences=int(expanded))
                    speak(condition)
                    speak(results)
                except:
                    speak(f"{REFER_USER}, Couldn't find anything about it.") if condition != "According to Wikipedia" else speak(None)
            
    def Greet_at_Start():
        Main.Chatbot.Chat("@starting")

    class Google:
        "Googles the given query"
        def __init__(self, query, Return_answer=False):
            query = str(query)
            query = query.replace("google search " , "")
            query = query.replace("google " , "")
            query1= query.replace(' ' , "+")
            pywhatkit.search(query1)
            results = Main.Wiki.Search(query, 'According to Internet')
            if Return_answer!=False:
                return results

    class SystemCommand:
        "All System Command lies here and also open|close commands"
        def System(command=None):
            command= str(command)
            if 'restart the pc' in command or 'restart pc' in command or 'restart computer' in command or 'restart the computer' in command: 
                answer = ("Restarting the Computer")
                press_and_release("win + d")
                time.sleep(0.3)
                press_and_release("alt + f4")
                time.sleep(0.3)
                press_and_release("down")
                time.sleep(0.2)
                press_and_release("enter")
            
            elif 'shutdown computer' in command or 'shutdown pc' in command or 'shutdown my pc' in command or 'shutdown the computer' in command: 
                answer = ("Shutting down the computer")
                press_and_release("win+d")
                time.sleep(0.3)
                press_and_release("alt+f4")
                time.sleep(0.3)
                press_and_release("enter")
            
            elif 'computer to sleep' in command or 'pc to sleep' in command or 'put the computer to sleep' in command: 
                speak("Putting Computer to sleep")
                press_and_release("win + d")
                time.sleep(0.3)
                press_and_release("alt + f4")
                time.sleep(0.3)
                press_and_release("up")
                time.sleep(0.2)
                press_and_release("enter")
            
            elif 'open settings' in command: 
                press_and_release("win + i")
                answer = ("Opened System Settings")
            
            elif 'lock computer' in command or 'lock the computer' in command or 'lock my pc' in command or 'lock the pc' in command: 
                press_and_release("win + l")
                answer = "Locked Computer"
            
            elif 'run prompt' in command: 
                press_and_release("win + r")
                answer = "Opened run prompt"

            elif 'open search' in command: 
                press_and_release("win + s")
                answer = "Done"
            
            elif 'open display settings' in command:
                if float(platform.release()) <= float(10): 
                    answer = (f"{REFER_USER}, You are on windows version lower than windows 10 so its ease of access at that time, ?Operation aborted?")
                elif float(platform.release()) >= float(10):
                    press_and_release("win + u")
            
            elif 'make a folder on desktop' in command:
                command = command.replace("make a folder on desktop" , "")
                press_and_release("win + d")
                time.sleep(0.2)
                rightClick(x=0,y=0)
                time.sleep(0.1)
                press_and_release("ctrl + shift + n")
                if 'of name ' in command:
                    command = command.replace("of name " , "")
                    write(command)
                    time.sleep(0.5)
                    press_and_release("enter")
                    
                else:
                    pass
                answer = ("Created folder on Desktop")
                speak(answer)
            else: 
                answer = None
            return answer

        def Sys(command):
            command = str(command)
            command = command.lower()
            if 'close task manager' in command: 
                os.system("taskkill /f /im taskmgr.exe")
                answer =("Closed Task Manager")

            elif 'close disk management' in command: 
                os.system("taskkill /f /im diskmgmt.msc")
                answer = ("Closed Disk Management")

            elif 'close cmd' in command or 'close terminal' in command: 
                os.system("taskkill /f /im cmd.exe")
                answer = "Closed CMD"

            elif 'close notepad' in command: 
                os.system("taskkill /f /im notepad.exe")
                answer = ("Closed Notepad")

            elif 'close file explorer' in command or 'close file manager' in command: 
                answer = ("Sorry, It cannot be done.")

            elif 'close registry editor' in command: 
                os.system("taskkill /f /im regedit.exe")
                answer = ("Closed Registry Editor")

            elif 'close device manager' in command: 
                os.system("taskkill /f /im devmgmt.msc")
                answer = ("Closed Device Manager")

            elif 'close device info' in command: 
                os.system("taskkill /f /im msinfo32.exe")
                answer = ("Closed System Information")

            elif 'hostname' in command: 
                os.system("hostname")
                answer = ("Printed Hostname")

            elif 'ip address' in command or "what is my ip address" in command: 
                os.system("ipconfig")
                answer = ("Printed IP Address")
            

            elif 'close system config' in command: 
                os.system("taskkill /f /im msconfig.exe")
                answer = "Closed System Configurations"
        

            elif 'close system info' in command: 
                os.system("taskkill /f /im msinfo32.exe")
                answer = ("Closed Microsoft Information")
            
            elif 'take screenshot' in command or 'take a screenshot' in command: 
                press_and_release("win + PrtScn")
                answer = ("ScreenShot Taken")
                Pic_path = f"C:\\Users\\{os.getlogin()}\\Pictures\\Screenshots"
                Files_counted = 0
                for files in os.listdir(Pic_path):
                    Files_counted+=1

                os.startfile(f"{Pic_path}\\Screenshot({Files_counted}).png")      
            
            elif 'go to desktop' in command: 
                press_and_release("win + d")
                answer = ("Done!, You're on Desktop now") 

            elif 'close chrome' in command or 'shutdown chrome' in command: 
                os.system("Taskkill /f /im chrome.exe")
                answer = ("Closed Chrome")
                os.system("cls")

            elif 'close camera' in command: 
                os.system("taskkill /f /im Camera.exe")
                answer = "Closed Camera"
            elif 'open control panel' in command: 
                os.system("control.exe")
                answer = "Opened Control Panel"

            elif 'close control panel' in command: 
                answer = ("[Operation Aborted!], You have to close it manually.")

            else:
                answer = Main.SystemCommand.System(command)
        
            return answer

    class Youtube:
        def __init__(self, query, Return_answer=False): 
            query = str(query)
            query = query.replace("youtube " , "")
            query = query.replace("youtube search " , "")
            query1 = query.replace(" " , "+")
            if 'play+playlist' in query1: 
                Main.MusicPlayer("mood").start()
                Answer = "Started Playlist MOOD"

            elif 'play+' in query1: 
                query1 = query1.replace("play+" , "")
                pywhatkit.playonyt(query1)
                query1 = query1.replace("+" , " ")
                answer = f"Played {query1} on YouTube"
                speak(answer)

            else: 
                webbrowser.open_new_tab(f"https://www.youtube.com/results?search_query={query1}")
                answer = "Searched on YouTube"
            
            if Return_answer!=False:
                return answer
    
    class GetTime:
        def __ChangeSet__(hour):
            hour = int(hour)
            if hour == 12 : return 12, "P M"
            elif hour == 13: return 1, "P M"
            elif hour == 14: return 2, "P M"
            elif hour == 15: return 3, "P M"
            elif hour == 16: return 4, "P M"
            elif hour == 17: return 5, "P M"
            elif hour == 18: return 6, "P M"
            elif hour == 19: return 7, "P M"
            elif hour == 20: return 8, "P M"
            elif hour == 21: return 9, "P M"
            elif hour == 22: return 10, "P M"
            elif hour == 23: return 11, "P M"
            elif hour == 24: return 12, "A M"
            else: 
                return int(hour),"A M"

        # def __date_to_text__(data=None):
            if data!=None:
                if data == "1": return "First"
                elif data == "2": return "Second"
                elif data == "3": return "Third"
                elif data == "4": return "Fourth"
                elif data == "5": return "Fifth"
                elif data == "6": return "Sixth"
                elif data == "7": return "Seventh"
                elif data == "8": return "Eighth"
                elif data == "9": return "Nineth"
                elif data == "10": return "Tenth"
                elif data == "11": return "Eleventh"
                elif data == "12": return "Twelfth"
                elif data == "13": return "Thirteenth"
                elif data == "14": return "Fourteenth"
                elif data == "15": return "Fifteenth"
                elif data == "16": return "Sixteenth"
                elif data == "17": return "Seventeenth"
                elif data == "18": return "Eighteenth"
                elif data == "19": return "Nineteenth"
                elif data == "20": return "Twentyth"
                elif data == "21": return "Twenty first"
                elif data == "22": return "Twenty Second"
                elif data == "23": return "Twenty third"
                elif data == "24": return "Twenty fourth"
                elif data == "25": return "Twenty Fifth"
                elif data == "26": return "Twenty Sixth"
                elif data == "27": return "Twenty Seventh"
                elif data == "28": return "Twenty Eighth"
                elif data == "29": return "Twenty Nineth"
                elif data == "30": return "Thirty"
                elif data == "31": return "Thirty First"
                else:
                    raise ValueError("Value for Data invalid at Function {_date_to_text_}, line [420]")
                
        def onlytime(): 
            hour = datetime.datetime.now().hour
            minute = datetime.datetime.now().minute
            return hour, minute  

        def __returner__():
            hour = datetime.datetime.now().hour
            minute = datetime.datetime.now().minute
            Day = datetime.datetime.now().day
            month = datetime.datetime.now().strftime("%m")
            year = datetime.datetime.now().year
            hour = int(hour)
            _date_ = Main.GetTime.MonChanger(month)

            if hour <= 12: _get = "A M "
            elif hour >= 13:  hour,_get = Main.GetTime.__ChangeSet__(hour)

            return hour, minute, _get, Day, _date_, year
        
        def GiveTime(condition=None):
            if "getDay" in condition: con = "day"
            elif "getTime" in condition: con = "time"
            else: con = "both"
            
            hour, minute, _get, Day, _date_ , year = Main.GetTime.__returner__()
            
            if con == "day": return f"{Day}-{_date_}-{year}"
            elif con == "time": return f"{hour}:{minute} {_get}" 
            else: return f"Time is {hour}:{minute} {_get} of date {Day}-{_date_}-{year}"

        def MonChanger(_time_=None):
            _time_ = int(_time_)
            if _time_ == 1:  return "January"
            elif _time_ == 2:  return "February"
            elif _time_ == 3:  return "March"
            elif _time_ == 4:  return "April"
            elif _time_ == 5:  return "May"
            elif _time_ == 6:  return "June"
            elif _time_ == 7:  return "July"
            elif _time_ == 8:  return "August"
            elif _time_ == 9:  return "September"
            elif _time_ == 10:  return "October"
            elif _time_ == 11:  return "November"
            elif _time_ == 12:  return "December"
            else:
                raise ValueError("Invalid data at Function {MonChanger}, line [471]")
    
    class Restarter:
        def res():
            try: os.startfile(f"{path}\\Lucas.py"); sys.exit()
            except Exception as e: speak(f"Error - [{e}]")

    class PathExe:
        def __find__(query):
            query = str(query)
            query = query.replace("start file " , "")
            query = query.replace("start " , "")
            query = query.replace("start a file named " , "")
            query = query.replace("open file " , "")
            query = query.replace("open " , "")
            query = query.replace("open a file named " , "")

            for files in os.listdir(f"{os.getcwd()}\\Custom_Path"):
                for lines in open(f"{os.getcwd()}\\Custom_Path\\{files}", "r"):
                    lines = str(lines)

                    thing, execution = lines.split(" : ")

                    execution = str(execution).replace("\n" , "")

                    if "{login}" in execution: execution = execution.replace("{login}" , f"{os.getlogin()}")

                    if query == thing:
                        if "https://" in execution:
                            webbrowser.open_new(f"{execution}")

                        elif "key:" in execution:
                            exe = execution.replace("key: " , "")
                            try:
                                press_and_release(exe)
                            except Exception as Error:
                                print(f"Error : {Error}")

                        else:
                            if os.path.exists(execution):
                                os.startfile(execution)
                            else:
                                speak("Sorry getting an error in finding and verifying path for file.")
                        
    class MusicPlayer:
        def __init__(self, playlist_name, Return_answer=False) -> None:
            self.name = str(playlist_name)
            self.answer = bool(Return_answer)

        def __music_number__(self):
            return random.choice([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19])

        def __Find_and_Start__(self):
            Selected_number = Main.MusicPlayer(self.name).__music_number__()
            IsFounded = False
            if self.name == "mood":
                if (os.path.exists(f"{os.getcwd()}\\Music_selector\\mood") == True):
                    for lines in open(f"{os.getcwd()}\\Music_selector\\mood\\playlist.music" , "r"):
                        lines = str(lines)
                        number, name , link = lines.split(" : ")
                        if int(number) == int(Selected_number):
                            IsFounded = True
                            speak(f"Playing {name}")
                            webbrowser.open(link)
                            if self.answer != False:
                                return f"Playing {name}"

            elif self.name == "old":
                if (os.path.exists(f"{os.getcwd()}\\Music_selector\\old") == True):
                    for lines in open(f"{os.getcwd()}\\Music_selector\\old\\playlist.music" , "r"):
                        lines = str(lines)
                        number, name , link = lines.split(" : ")
                        if int(number) == int(Selected_number):
                            IsFounded = True
                            speak(f"Playing {name}")
                            webbrowser.open(link)
                            if self.answer != False:
                                return f"Playing {name}"

            if IsFounded == False:
                Main.MusicPlayer(self.name, self.answer).start()

        def start(self):
            result = Main.MusicPlayer(self.name,self.answer).__Find_and_Start__()
            return result
    
    class System_Info:
        def Battery(value=None): 
            if value=="%": battery = psutil.sensors_battery(); percentage = battery.percent ; return percentage
        
        def Connect_to_Wifi():
            os.system(f'''cmd /c "netsh wlan show profiles"'''); speak("Trying to connect to default connection"); os.system(f'''cmd /c "netsh wlan connect name=WiFi"''')

        def __data_connection_checker__():
            try:
                requests.get(f"https://www.google.com")
                return True
            except:
                return False
    
        def Repeated_tasks():
            global Said_Battery_Warning, WARNED
            if Said_Battery_Warning == False:
                if Main.System_Info.Battery("%") <= 10:
                    speak(f"Excuse me {REFER_USER}, Your laptop's battery is very low. Please connect it to its charger.")
                    WARNED = True
                    Said_Battery_Warning = True
                elif Main.System_Info.Battery("%") <= 20:
                    speak(f"Excuse me {REFER_USER}, Your laptop's battery is very low. Please connect it to its charger.")
                    Said_Battery_Warning = True
                elif Main.System_Info.Battery("%") >= 99:
                    if WARNED:pass 
                    else:
                        WARNED = True
                        speak(f"Excuse me {REFER_USER}, Your laptop's battery seems to be fully charged. You can remove your device's charger.")

            if WARNED == True and Said_Battery_Warning == True:
                speak(f"Sorry {REFER_USER} due to insufficient battery percentage I am going to sleep")
                sys.exit()
                   
            if Main.System_Info.__data_connection_checker__() != True:
                while True:
                    if Main.System_Info.__data_connection_checker__() == True: break 
                    else: Main.System_Info.Connect_to_Wifi()
                    time.sleep(3)
    
    class Responder:
        def Execute_query(Argument=None):

            Main.System_Info.Repeated_tasks()

            global Attrib
            if Argument!=None: query = str(Argument)
            else: query = "none"
            
            if query != "none":
                    if 'google search' in query or "on google " in query:
                        speak("Searching on Google")
                        results = Main.Google(query, True)
                        listtohistory(f"{query}")

                    elif ' on wikipedia' in query or 'define ' in query or "wikipedia search " in query or "who is " in query:
                        Main.Wiki.Search(query) 
                        listtohistory(f"{query}")

                    elif 'youtube ' in query or "youtube search " in query:
                        results = Main.Youtube(query, True)
                        listtohistory(F"{query}")
                        
                    elif 'exit system' in query or 'exit' in query: 
                        listtohistory(f"{query}")
                        os.system(f"startGUI.pyw exit")
                        sys.exit()

                    elif 'restart yourself' in query or 'recharge yourself' in query:
                        listtohistory(f"{query}")
                        Main.Restarter.res()
                    
                    elif "do last task again" in query or "do it again" in query:
                        task = LastTask()
                        Main.Responder.res(task)
                    
                    elif "start " in query or "open " in query:
                        results = Main.PathExe.__find__(query)
                        listtohistory(f"{query}")

                    elif "press " in query:
                        query = query.replace("press " , "")
                        query = query.replace("key " , "")
                        query = query.replace(" plus " , "+")
                        print(query)
                        try:
                            press_and_release(query)
                        except Exception as Error:
                            print(f"Error : in Execute query : {Error}")

                    elif "play a old song" in query or "why don't you play a old song" in query :
                        results = Main.MusicPlayer("old", True).start()
                        speak(results, 4)
                        listtohistory(f"{query}")

                    elif 'play a song' in query or "why don't you play a song" in query:
                        results = Main.MusicPlayer("mood").start()
                        listtohistory(f"{query}")

                    elif "system command" in query or "command " in query or "system " in query or "close " in query:
                        query = query.replace("system command " , "")
                        Main.SystemCommand.Sys(query)
                    else:pass
        
        def res(Argument=None, ExtraArg=None):
            if Argument == None: query = takecommand().lower()
            else: query = str(Argument)

            if ExtraArg != "Replied": Main.Chatbot.Chat(query)
            else: Main.Responder.Execute_query(query)
    
if __name__=="__main__":
    try:

        os.system(f"startGUI.pyw startfile")

        ChangeTEXTOnGUI("Started")
        os.system("title Lucas")
        os.system("cls")
        Main.Greet_at_Start()

        while True:
            try:
                Main.Responder.res()
            except:
                os.system("startGUI.pyw stop")
                sys.exit()

    except Exception as error:
        print(f"Error :\n\n{error}")